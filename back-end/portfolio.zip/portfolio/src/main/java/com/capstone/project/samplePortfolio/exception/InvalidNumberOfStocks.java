package com.capstone.project.samplePortfolio.exception;

public class InvalidNumberOfStocks extends Exception{
    public InvalidNumberOfStocks(String msg){
        super(msg);
    }
}
